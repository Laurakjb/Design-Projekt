package Controller;

import model.LoanContainer;
import model.Loan;
import model.Friend;
import model.Copy;

public class LoanController {
    private LoanContainer loanContainer;
    
    public LoanController() {
      loanContainer = LoanContainer.getInstance();
      
    }
    
    public Copy addCopyBySerialNumberToLoan(int serialNumber) {
        LPController lpController = new LPController();
        Copy copy = lpController.findCopyBySerialNumber(serialNumber);
        if (copy == null) {
           return null;
       }
        return copy;
    }
    
    public Friend addFriendByPhoneToLoan(String phone){
        FriendController friendController = new FriendController();
        Friend friend = friendController.findFriendByPhone(phone); 
        if (friend == null) {
           return null;
        }
        return friend;
    }
    public Loan createLoan(String phone, int serialNumber, int loanNumber, String borrowDate, String returnDate, boolean status) {
       FriendController friendController = new FriendController();
       LPController lpController = new LPController();
        
       
       Friend friend = friendController.findFriendByPhone(phone); 
       if (friend == null) {
           return null;
       }
       Copy copy = lpController.findCopyBySerialNumber(serialNumber);
       if (copy == null) {
           return null;
       }
       
       Loan loan = new Loan(loanNumber, borrowDate,returnDate, status, friend, copy);
       loanContainer.addLoan(loan);
       return loan;
       
    
    }
    /*public Loan createLoan(int loanNumber, String borrowDate, String returnDate, boolean status, Friend friend, Copy copy) {
       
       Loan loan = new Loan(loanNumber, borrowDate,returnDate, status, friend, copy);
       
       loanContainer.addLoan(loan);
       return loan;
       
    
    }*/
    
}

