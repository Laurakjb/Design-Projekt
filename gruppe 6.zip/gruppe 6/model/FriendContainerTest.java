package model;



import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class FriendContainerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */

    
class FriendContainerTest {
    private FriendContainer container;

    @BeforeEach
    public void setUp() {
        container = FriendContainer.getInstance();
    }

    @Test
    public void testAddFriend() {
        Friend friend = new Friend("Anna Hansen", "12345678", "Sti 1", 8000, "Aalborg");
        container.addFriend(friend);

        assertEquals(friend, container.findFriendByPhone("12345678"), "finder freind via telefon nr");
    }

    @Test
    public void testFindFriendByPhoneNotFound() {
        Friend result = container.findFriendByPhone("00112233");

        
        assertNull(result, "returns null hvis ingen phone number er");
    }
}
