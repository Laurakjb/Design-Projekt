package model;
import java.util.ArrayList;

public class FriendContainer
{
    private ArrayList<Friend>friends;
    private static FriendContainer instance;
    private Friend friend;
    
    /**
     * Konstruktør for objekter af klassen LoanContainer
     */

    private FriendContainer() {
        friends = new ArrayList<>();
        //friends.add(new Friend("Anna Hansen", "12345678", "Sti 1", 8000, "Aalborg"));
        //friends.add(new Friend("Peter Nielsen", "98765432", "Sti 2", 9000, "Aarhus"));
        //friends.add(new Friend("Mette Larsen", "23456789", "Sti 3", 5000, "Odense"));
        Friend f = new Friend("Anna Hansen", "12345678", "Sti 1", 8000, "Aalborg");
        friends.add(f);
    }
    
    public static FriendContainer getInstance() {
        if (instance == null) {
            instance = new FriendContainer();
        }
        return instance;
    }
    
    public boolean addFriends(Friend f) {
        return friends.add(f);
    }
    
    public boolean addFriend(Friend friend) {
        return friends.add(friend);
    }
    
    public ArrayList<Friend> getFriends() {
        return friends;
    }
    
    public Friend findFriendByPhone(String phone) {
        int i = 0;
        while (i < friends.size()) {
            Friend friend = friends.get(i); 
            if (friend.getPhone().equals(i)) {
                return friend; 
            }
            i++; 
        }
        return null; 
    }
    
    public Friend findFriend(Friend f) {
    for (Friend friend : friends) {
        
        if (friend.getFriends().contains(f)) {
            return f; 
        }
    }
    return null; 
    }
}
