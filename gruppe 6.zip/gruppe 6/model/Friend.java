package model;
import java.util.ArrayList;
import java.util.List;

/**
 
Lav en beskrivelse af klassen Friend her.
@author (dit navn her)
@version (versions nummer eller dato her)*/
public class Friend
{
    // har sætter vi parrametrene til at finde vores friends
    private String name;
    private String phone;
    private String address;
    private int postalCode;
    private String city;
    private List<Friend> friends;
    // * Konstruktør for objekter af klassen Friend

    public Friend(String name, String phone, String address, int postalCode, String city)
    {
        // initialiser instansvariable
        this.name = name;
        this.phone = phone;
        this.address = address;
        this.postalCode = postalCode;
        this.city = city;
        this.friends = new ArrayList<>();
        
    }

    public String getPhone(){
        return phone;
    }
    
    public String getName(){
        return name;
    }
    
    
    
    public String getAddress(){
        return address;
    }
    public int getPostalCode(){
        return postalCode;
    }
    public String getCity(){
        return city;
    }
    
    public List<Friend> getFriends() {
        return friends;
    }
}
